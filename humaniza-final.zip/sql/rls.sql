-- SQL para crear la tabla 'history' y activar RLS

create table if not exists public.history (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id),
  mode text not null,
  tone text,
  input_text text,
  output_text text,
  created_at timestamptz default now()
);

-- Activar Row Level Security (RLS)
ALTER TABLE public.history ENABLE ROW LEVEL SECURITY;

-- Política: cada usuario puede ver solo su historial
CREATE POLICY "Usuarios solo ven su propio historial"
ON public.history FOR SELECT
USING (auth.uid() = user_id);

-- Política: solo pueden insertar sus propios registros
CREATE POLICY "Usuarios solo insertan su propio historial"
ON public.history FOR INSERT
WITH CHECK (auth.uid() = user_id);
