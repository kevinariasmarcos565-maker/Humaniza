import React, { useState, useEffect } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function Home() {
  const [input, setInput] = useState('')
  const [result, setResult] = useState('')
  const [loading, setLoading] = useState(false)
  const [mode, setMode] = useState('summary')
  const [tone, setTone] = useState('Natural')
  const [user, setUser] = useState(null)

  useEffect(()=>{
    supabase.auth.getSession().then(r => {
      if (r.data?.session) setUser(r.data.session.user)
    })
    const { data: listener } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null)
    })
    return ()=> listener?.subscription?.unsubscribe?.()
  },[])

  async function handleSubmit(e) {
    e?.preventDefault?.()
    if (!input.trim()) return
    setLoading(true)
    setResult('')
    try {
      const endpoint = mode === 'summary' ? '/api/summarize' : '/api/humanize'
      const resp = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: input, tone }),
      })
      const json = await resp.json()
      setResult(json.output ?? json.error ?? '')
      try {
        const user_id = user?.id ?? null
        await supabase.from('history').insert([{
          user_id,
          mode: mode === 'summary' ? 'summary' : 'humanize',
          tone,
          input_text: input,
          output_text: json.output ?? json.error ?? ''
        }])
      } catch (err) {
        console.error('Error guardando historial:', err)
      }
    } catch (err) {
      setResult('Error: ' + (err.message || err.toString()))
    } finally {
      setLoading(false)
    }
  }

  async function signOut() {
    await supabase.auth.signOut()
    setUser(null)
  }

  return (
    <main className="min-h-screen p-8">
      <div className="mx-auto max-w-4xl bg-white rounded-2xl shadow p-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-semibold mb-2">{process.env.NEXT_PUBLIC_APP_NAME || 'Humaniza'}</h1>
          <div>
            {user ? (
              <div className="flex items-center gap-3">
                <span className="text-sm text-slate-500">{user.email}</span>
                <button onClick={signOut} className="px-3 py-1 border rounded">Salir</button>
              </div>
            ) : (
              <a href="/login" className="px-3 py-1 border rounded">Iniciar sesión</a>
            )}
          </div>
        </div>

        <p className="text-sm text-slate-500 mb-4">Pega tu texto, elige "Resumir" o "Humanizar" y obtén un resultado natural listo para usar.</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <label className="block">
            <span className="text-sm font-medium">Texto de entrada</span>
            <textarea value={input} onChange={e=>setInput(e.target.value)} rows={10} className="w-full mt-2 p-3 rounded-lg border border-slate-200 resize-none" placeholder="Pega aquí el artículo o texto..." />
          </label>

          <div className="flex gap-3 items-center">
            <div className="flex items-center gap-2">
              <label className={`px-3 py-1 rounded-lg border cursor-pointer ${mode==='summary' ? 'bg-slate-100 border-slate-300' : ''}`}>
                <input type="radio" name="mode" checked={mode==='summary'} onChange={()=>setMode('summary')} className="mr-2" /> Resumir
              </label>
              <label className={`px-3 py-1 rounded-lg border cursor-pointer ${mode==='humanize' ? 'bg-slate-100 border-slate-300' : ''}`}>
                <input type="radio" name="mode" checked={mode==='humanize'} onChange={()=>setMode('humanize')} className="mr-2" /> Humanizar
              </label>
            </div>

            <select value={tone} onChange={e=>setTone(e.target.value)} className="ml-auto rounded-lg border px-3 py-2">
              <option>Natural</option>
              <option>Conversacional</option>
              <option>Formal</option>
              <option>Académico</option>
              <option>Creativo</option>
            </select>

            <button type="submit" disabled={loading} className="ml-2 bg-slate-800 text-white px-4 py-2 rounded-lg">
              {loading ? 'Procesando...' : (mode==='summary' ? 'Resumir' : 'Humanizar')}
            </button>
          </div>
        </form>

        <section className="mt-6">
          <h2 className="text-lg font-medium">Resultado</h2>
          <div className="mt-2 p-4 bg-slate-50 rounded-lg border border-slate-100 min-h-[120px]">
            {result ? (
              <div>
                <pre className="whitespace-pre-wrap">{result}</pre>
                <div className="mt-3 flex gap-2">
                  <button onClick={()=>navigator.clipboard.writeText(result)} className="px-3 py-1 border rounded">Copiar</button>
                  <a href="/history" className="px-3 py-1 border rounded">Ver historial</a>
                </div>
              </div>
            ) : (
              <p className="text-sm text-slate-400">Aquí aparecerá el resultado procesado por la IA.</p>
            )}
          </div>
        </section>
      </div>
    </main>
  )
}
