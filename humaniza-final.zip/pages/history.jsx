import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function History() {
  const [data, setData] = useState([])

  useEffect(() => {
    async function load() {
      const userResp = await supabase.auth.getUser()
      const user = userResp.data?.user
      if (!user) {
        const { data } = await supabase.from('history').select('*').order('created_at', { ascending: false }).limit(20)
        setData(data || [])
      } else {
        const { data } = await supabase.from('history').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(50)
        setData(data || [])
      }
    }
    load()
  }, [])

  return (
    <main className="p-8 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Historial</h1>
      <ul className="space-y-4">
        {data.map(item => (
          <li key={item.id} className="border rounded p-4 bg-white shadow-sm">
            <p className="text-xs text-gray-500">{new Date(item.created_at).toLocaleString()}</p>
            <p className="font-semibold mt-1">{item.mode.toUpperCase()} — {item.tone}</p>
            <p className="mt-2 text-sm text-gray-700">{item.output_text}</p>
          </li>
        ))}
      </ul>
    </main>
  )
}
