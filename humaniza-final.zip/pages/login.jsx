import { useState } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function Login() {
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')

  async function handleLogin(e) {
    e.preventDefault()
    const { error } = await supabase.auth.signInWithOtp({ email })
    if (error) setMessage(error.message)
    else setMessage('Revisa tu correo para iniciar sesión (enlace mágico enviado).')
  }

  async function handleGoogle() {
    const { error } = await supabase.auth.signInWithOAuth({ provider: 'google' })
    if (error) setMessage(error.message)
  }

  return (
    <main className="min-h-screen flex flex-col justify-center items-center p-6">
      <div className="max-w-md w-full bg-white p-6 rounded-lg shadow">
        <h1 className="text-2xl mb-4">Iniciar sesión</h1>
        <form onSubmit={handleLogin} className="space-y-3">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Tu correo"
            className="border rounded p-2 w-full"
          />
          <button type="submit" className="bg-slate-800 text-white px-4 py-2 rounded w-full">Enviar enlace mágico</button>
        </form>
        <div className="text-center my-4 text-gray-400">— o —</div>
        <button onClick={handleGoogle} className="bg-red-500 text-white w-full py-2 rounded hover:bg-red-600">Iniciar con Google</button>
        <p className="mt-4 text-sm text-gray-500">{message}</p>
      </div>
    </main>
  )
}
