export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const { text = '', tone = 'Natural' } = req.body ?? {}
  if (!text) return res.status(400).json({ error: 'text is required' })

  try {
    const system = `Eres un asistente que resume textos de forma concisa, clara y precisa. Tono: ${tone}. Limita el resumen a lo esencial.`
    const prompt = `Texto a resumir:\n\n${text}`
    const payload = {
      model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: prompt }
      ],
      temperature: 0.2,
      max_tokens: 500
    }

    const resp = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify(payload)
    })

    if (!resp.ok) {
      const text = await resp.text()
      return res.status(500).json({ error: 'OpenAI error: ' + text })
    }
    const data = await resp.json()
    const output = data.choices?.[0]?.message?.content ?? ''
    return res.status(200).json({ output })
  } catch (err) {
    console.error(err)
    return res.status(500).json({ error: err.message || String(err) })
  }
}