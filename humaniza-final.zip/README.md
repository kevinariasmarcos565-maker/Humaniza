# Humaniza

Aplicación para resumir y humanizar textos usando IA. Interfaz en español y autenticación con Supabase (correo y Google).

## Configuración rápida
1. Copia `.env.example` a `.env.local` y añade tus claves.
2. `npm install`
3. `npm run dev`
4. Abre http://localhost:3000

## Notas
- Ejecuta el SQL en `sql/rls.sql` en la consola SQL de Supabase para activar RLS.
- Configura Google OAuth en Supabase (redirect URI: `https://tu-dominio.vercel.app` y `http://localhost:3000` para desarrollo).
